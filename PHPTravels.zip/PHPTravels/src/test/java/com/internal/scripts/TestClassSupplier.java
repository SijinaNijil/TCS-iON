package com.internal.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.internal.pages.AdminFrontEndStageII;
import com.internal.pages.Login;
import com.internal.pages.SupplierBackEnd;
import com.internal.utilities.ExcelUtility;

import net.jodah.failsafe.internal.util.Assert;

public class TestClassSupplier extends TestBase{
SupplierBackEnd objSupplier;
//AdminFrontEndStageII objSupplier;
	
	@Test(priority=0)
    public void verifyLogin() throws IOException, InterruptedException  {
    //Create Login Page object
		//objSupplier = new AdminFrontEndStageII(driver);
	objSupplier = new SupplierBackEnd(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));

String email = ExcelUtility.getCellData(0, 5);
objSupplier.setEmail(email);
String invalidPass = ExcelUtility.getCellData(1, 2);
objSupplier.setPassword(invalidPass);
objSupplier.clickLogin();
Thread.sleep(2000);
String invemail=ExcelUtility.getCellData(0, 2);
objSupplier.setEmail(invemail);
String passwd = ExcelUtility.getCellData(1, 5);
objSupplier.setPassword(passwd);
Thread.sleep(2000);
objSupplier.clickLogin();
Thread.sleep(2000);
objSupplier.setEmail(invemail);
objSupplier.setPassword(invalidPass);
Thread.sleep(2000);
objSupplier.clickLogin();
Thread.sleep(2000);
objSupplier.setEmail(email);
objSupplier.setPassword(passwd);
Thread.sleep(2000);
objSupplier.clickLogin();
objSupplier.Booking();
driver.quit();

}
	@Test(priority=1)
    public void verifyLinks() throws IOException, InterruptedException  {
    //Create Login Page object
		//objSupplier = new AdminFrontEndStageII(driver);
	objSupplier = new SupplierBackEnd(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	String email = ExcelUtility.getCellData(0, 5);
    Thread.sleep(2000);
    objSupplier.setEmail(email);
    String pass = ExcelUtility.getCellData(1, 5);
    Thread.sleep(2000);
    objSupplier.setPassword(pass);
    objSupplier.clickLogin();
    Thread.sleep(2000);
    objSupplier.lnkWeb();
    Thread.sleep(2000);
    
    
	
}}
