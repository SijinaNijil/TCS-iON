package com.internal.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.swing.text.TabableView;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v95.browser.Browser;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.internal.constants.AutomationConstatnts;
import com.internal.pages.AgentFrontEnd;
import com.internal.pages.Login;
import com.internal.utilities.ExcelUtility;
public class TestClass extends TestBase {
Login objLogin;
	
	@Test(priority=1)
    public void verifyLogin() throws IOException, InterruptedException  {
    //Create Login Page object
	
	objLogin = new Login(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
objLogin.clickLoginLink();
String email = ExcelUtility.getCellData(0, 0);
objLogin.setEmail(email);
String invalidPass = ExcelUtility.getCellData(1, 2);
objLogin.setPassword(invalidPass);
objLogin.clickLogin();
Thread.sleep(2000);
String invemail=ExcelUtility.getCellData(0, 2);
objLogin.setEmail(invemail);
String passwd = ExcelUtility.getCellData(1, 0);
objLogin.setPassword(passwd);
Thread.sleep(2000);
objLogin.clickLogin();
Thread.sleep(2000);
objLogin.setEmail(invemail);
objLogin.setPassword(invalidPass);
Thread.sleep(2000);
objLogin.clickLogin();
Thread.sleep(2000);
objLogin.setEmail(email);
objLogin.setPassword(passwd);
Thread.sleep(2000);
objLogin.clickLogin();
objLogin.clickAddFunds();
Thread.sleep(2000);
//Thread.sleep(2000);
//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
//Thread.sleep(2000);
objLogin.findPayPal3();
driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
Thread.sleep(2000);
objLogin.clickpaypal();
driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
/*objLogin.clickProfile();
Thread.sleep(2000);
String address = ExcelUtility.getCellData(0, 1);
objLogin.setAddress(address);
driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
Thread.sleep(2000);
//objLogin.updateProfile();
//objLogin.clickLogout();
/*		Thread.sleep(2000);
	
		objLogin.clickAddFunds();
		Thread.sleep(2000);
		objLogin.clickpaypal();
	objLogin.clickProfile();
		Thread.sleep(2000);
		String address = ExcelUtility.getCellData(0, 1);
		objLogin.setAddress(address);
		objLogin.updateProfile();
		//objLogin.linkBooking();
		//String expectedURL ="https://www.phptravels.net/hotels/booking/invoice/0541/182";
	  //  String actuaLURL=driver.getCurrentUrl();
	 //   Assert.assertEquals(expectedURL,actuaLURL);
	    Thread.sleep(2000); */
  
    }
	//--------------end of user---------------------------------
	
	//-------------agent front end
/*	
AgentFrontEnd objAgent;
	
	@Test(priority=2)
    public void verifyAgentLogin() throws IOException, InterruptedException  {
    //Create Login Page object
	
		objAgent = new AgentFrontEnd(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
	objAgent.clickLoginLink();
String email = ExcelUtility.getCellData(0, 0);
objAgent.setEmail(email);
String invalidPass = ExcelUtility.getCellData(1, 2);
objAgent.setPassword(invalidPass);
objAgent.clickLogin();
Thread.sleep(2000);
String invemail=ExcelUtility.getCellData(0, 2);
objAgent.setEmail(invemail);
String passwd = ExcelUtility.getCellData(1, 0);
objAgent.setPassword(passwd);
Thread.sleep(2000);
objAgent.clickLogin();
Thread.sleep(2000);
objAgent.setEmail(invemail);
objAgent.setPassword(invalidPass);
Thread.sleep(2000);
objAgent.clickLogin();
Thread.sleep(2000);
objAgent.setEmail(email);
objAgent.setPassword(passwd);
Thread.sleep(2000);
objAgent.clickLogin();
//----------------------------------------------------------------------------------------
objAgent.linkBooking();
Thread.sleep(2000);

//----------------------------------------------------------------------------------------
objAgent.clickAddFunds();
//---------------------------------------------------------------------------------------
objAgent.clickProfile();
//----------------------------------------------------------------------------------------
objAgent.clickHome();
//--------------------------------------------------------------------------------------
objAgent.clickHotels();
objAgent.clickSearch();
*/
}