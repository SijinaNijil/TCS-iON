package com.internal.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.internal.pages.CustomerFrontEnd;
import com.internal.pages.Login;
import com.internal.utilities.ExcelUtility;

public class TestClassCustomer extends TestBase {
CustomerFrontEnd objCustomer;
	
	@Test(priority=1)
    public void verifyLogin() throws IOException, InterruptedException  {
    //Create Login Page object
	
	objCustomer = new CustomerFrontEnd(driver);
    //login to application clickLoginLink
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	WebDriverWait wait=new WebDriverWait(driver, 20); 
	//element1 = wait.until(ExpectedConditions.elementToBeClickable(By.className("fa-stack-1x")));
objCustomer.clickLoginLink();
String email = ExcelUtility.getCellData(0, 0);
objCustomer.setEmail(email);
String invalidPass = ExcelUtility.getCellData(1, 2);
objCustomer.setPassword(invalidPass);
objCustomer.clickLogin();
Thread.sleep(2000);
String invemail=ExcelUtility.getCellData(0, 2);
objCustomer.setEmail(invemail);
String passwd = ExcelUtility.getCellData(1, 0);
objCustomer.setPassword(passwd);
Thread.sleep(2000);
objCustomer.clickLogin();
Thread.sleep(2000);
objCustomer.setEmail(invemail);
objCustomer.setPassword(invalidPass);
Thread.sleep(2000);
objCustomer.clickLogin();
Thread.sleep(2000);
objCustomer.setEmail(email);
objCustomer.setPassword(passwd);
Thread.sleep(2000);
objCustomer.clickLogin();
//link test

objCustomer.chkLinkAddFunds();
String expectedURL ="https://www.phptravels.net/account/add_funds";
String actuaLURL=driver.getCurrentUrl();
Assert.assertEquals(expectedURL,actuaLURL);
Thread.sleep(2000);

objCustomer.chkLinkBooking();

String expectedURL1 ="https://www.phptravels.net/account/bookings";
String actuaLURL1=driver.getCurrentUrl();
Assert.assertEquals(expectedURL1,actuaLURL1);
Thread.sleep(2000);

//objCustomer.chkLinkDashboard();


objCustomer.chkLinkProfile();
String expectedURL2 ="https://www.phptravels.net/account/profile";
String actuaLURL2=driver.getCurrentUrl();
Assert.assertEquals(expectedURL2,actuaLURL2);
Thread.sleep(2000);


objCustomer.chkLinkLogout();
String expectedURL4 ="https://www.phptravels.net/login";
String actuaLURL4=driver.getCurrentUrl();
Assert.assertEquals(expectedURL4,actuaLURL4);
Thread.sleep(2000);

objCustomer.setEmail(email);
objCustomer.setPassword(passwd);
Thread.sleep(2000);
objCustomer.clickLogin();
objCustomer.clickProfile();
Thread.sleep(2000);
String address = ExcelUtility.getCellData(0, 1);
objCustomer.setAddress(address);
objCustomer.updateProfile();
//objCustomer.linkBooking();
String expectedURL5 ="https://www.phptravels.net/account/profile/success";
  String actuaLURL5=driver.getCurrentUrl();
  Assert.assertEquals(expectedURL5,actuaLURL5);
Thread.sleep(2000); 

//objCustomer.linkBooking();
objCustomer.updateUID();
	/*	String expectedURL6 ="https://www.phptravels.net/flights/booking/invoice/3652/2";
	   String actuaLURL6=driver.getCurrentUrl();
	   Assert.assertEquals(expectedURL6,actuaLURL6);
	    Thread.sleep(2000);
/*

objCustomer.clickAddFunds();
Thread.sleep(2000);
objCustomer.findPayPal3();
driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
Thread.sleep(2000);
objCustomer.clickpaypal();
String expectedURL5 ="https://www.phptravels.net/payment/paypal";
String actuaLURL5=driver.getCurrentUrl();
Assert.assertEquals(expectedURL5,actuaLURL5);
Thread.sleep(2000);
*/
driver.quit();
}
}
