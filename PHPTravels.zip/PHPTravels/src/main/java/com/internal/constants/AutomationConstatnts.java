package com.internal.constants;

public class AutomationConstatnts {
	public static final String HOMEPAGETITLE ="Dashboard - PHPTRAVELS";
}
