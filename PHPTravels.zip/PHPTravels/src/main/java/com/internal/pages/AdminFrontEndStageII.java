package com.internal.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

public class AdminFrontEndStageII {
	WebDriver driver;
	//
	@FindBy(xpath="//span[text()='Email']")
	public WebElement emailSpan;
	@FindBy(xpath="//body/div/div/main/div/div/div/div/div/form/div/label/input[@type='text']")
	public WebElement emailBox;
	@FindBy(xpath="//span[text()='Password']")
	public WebElement passSpan;
	@FindBy(xpath="//body/div/div/main/div/div/div/div/div/form/div[2]/label/input[@type='password']")
	public WebElement passBox;
	//body/nav//div/div/ul/li[2]/a[text()='Bookings']
	
	//body/nav/div/div/ul/li/a
	
	@FindBy(xpath="//*[@id='booking_status']")
	public WebElement selctcls;
	 Select select = new Select(selctcls);
     // select an item with text visible
    
	@FindBy(xpath="//body/nav/div/div/ul/li/a")
	public WebElement lnkWeb;
	
	@FindBy(xpath="//form/div[4]/button[@type='submit']")
	public WebElement adminLogin;
	
	@FindBy(xpath="//body/nav//div/div/ul/li[2]/a[text()='Bookings']")
	public WebElement adminBooking;
	
	//select[@id='payment_status']
	
	@FindBy(xpath="//select[@id='payment_status']")
	public WebElement statusPaid;
	//select[@id='payment_status']/option[text()='paid']
	
	@FindBy(xpath="//select[@id='payment_status']/option[text()='paid']")
	public WebElement clkPaid;
	
	@FindBy(xpath="//table/tbody//tr/td[14]/a")
	public WebElement clkInvoice;
	//table/tbody/tr/td[11]/select[@id='booking_status']
	
	@FindBy(xpath="//table/tbody/tr/td[11]/select[@id='booking_status']")
	public WebElement clkCancel;
	
	//table/tbody/tr/td[11]/select[@id='booking_status']/option[@class='Cancelled']
	
	@FindBy(xpath="//table/tbody/tr/td[11]/select[@id='booking_status']/option[2]")
	public WebElement clkCancel1;
	
	//table/tbody/tr/td[15]/button
	
	@FindBy(xpath="//table/tbody/tr/td[15]/button")
	public WebElement clkDel;
	
	@FindBy(xpath="//body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div[text()]")
	public WebElement pendCount;
	
	@FindBy(xpath="//body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div/div/div[2]")
	public WebElement pending;
	
	@FindBy(xpath="//select[@id='booking_status']/option[text()='pending']")
	public WebElement pending1;
	
	public AdminFrontEndStageII(WebDriver driver){
        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
	public void setEmail(String strEmail){
	
    	emailBox.sendKeys(strEmail);     
    }
	public void setPassword(String strPass){
		
    	passBox.sendKeys(strPass);     
    }
public void adminLogin(){
		adminLogin.click();
    	    
    }

public void pendCount(){
	String pendcount = pendCount.getText();
	
	    
}
public void adminBooking(){
	adminBooking.click();
	    
}
public void penToConfrm(){
	
	//statusPaid.click();
	pending1.isSelected();
}

public void statusPaid(){
	statusPaid.click();
	
	    
}
public void clkPaid(){
	clkPaid.click();
	clkInvoice.click();
	
	    
}
public void clkCancel(){
	clkCancel.click();
	
	
	    
}
public void clkCancel1(){
	clkCancel1.click();
	//clkDel.click();
	
	
	    
}
public void lnkWeb(){
	lnkWeb.click();

}
}