package com.internal.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
	WebDriver driver;
	//-------------------------login-------------------------------------
	@FindBy(xpath="//body/header//div/div/div/div/div/div/a[2][text()='Login']")
	public WebElement logLink;
	@FindBy(xpath="/html/body//form/div//div/input[@type='email']")
	public WebElement email;
	@FindBy(xpath="/html/body//form/div[2]/div/input[@type='password']")
	public WebElement password;
	@FindBy(xpath="/html/body//form/div[3]/button[@type='submit']")
	public WebElement buttonLogin;
	//---------------------My Profile
	//
	@FindBy(xpath="//body/div/div//div[3]/ul//li[4]/a[text()=' My Profile']")
	public WebElement buttonProfile;
	//input[@name='address1']
	@FindBy(xpath="//input[@name='address1']")
	public WebElement address;
	//button[text()='Update Profile']
	@FindBy(xpath="//body/section/div/div[2]/div/div/div//div[2]//form//div[3]/button[@type='submit']")
	public WebElement updateProfile;
	@FindBy(xpath="//form")
	public WebElement formClick;
	//_______________________booking__________________________________________
	@FindBy(xpath="//body/div/div//div[3]/ul/li[2]/a[text()=' My Bookings']")
	public WebElement linkBooking;
	@FindBy(xpath="//table//a[text()=' View Voucher']")
	public WebElement linkVoucher;
	@FindBy(xpath="//button[@id='currency']")
	public WebElement linkUID;
	@FindBy(xpath="//div/div/div[2]/div/div/div/div/ul//a[text()=' INR']")
    public WebElement linkIND;
	//----------------------Add funds--------------------------------------
	@FindBy(xpath="//body/div/div//div[3]/ul/li[3]/a[text()=' Add Funds']")
	public WebElement linkAddFunds;
	////form/div/div/div/div/div/ul/div[4]/div/div/input[@type='radio']
	//
	@FindBy(xpath="//form/div/div/div/div/div/ul/div[4]/div/div//input[@id='gateway_paypal']")
	public WebElement radioPayPal;
	@FindBy(xpath="//input[starts-with(@name,'payment')and@value='paypal']")
	public WebElement PayPal;
	
	@FindBy(xpath="//i[@class='la la-arrow-right']")
	public WebElement PayNow;
	@FindBy(xpath="//form/div/div[2]/div/button[text()='Pay Now ']")
	public WebElement linkPayNow;
	//--------------------------logout-----------------
	
	@FindBy(xpath="//body/div/div//div[3]/ul/li[5]/a[text()=' Logout']")
	public WebElement linkLogout;
	public Login(WebDriver driver){
        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
	//Set user name in textbox
	public void clickLoginLink(){
        logLink.click();
}
    public void setEmail(String strEmail){
    	email.clear();
    	email.sendKeys(strEmail);     
    }
 //Set password in password textbox
    public void setPassword(String strPassword){
    	password.clear();
       password.sendKeys(strPassword);
    }
    public void setInvalidEmail(String strInvalidEmail){
    	email.clear();
    	email.sendKeys(strInvalidEmail);     
    }
 //Set password in password textbox
    public void setInvalidPassword(String strInvalidPassword){
    	password.clear();
       password.sendKeys(strInvalidPassword);
    }
  //Click on login button
    public void clickAddFunds() throws InterruptedException{
    	linkAddFunds.click();
    
    	
    	
    }
   public void findPayPal3()
    {
    	JavascriptExecutor executor =  (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", PayPal);
    }
    public void clickpaypal(){
    	
    	PayPal.sendKeys(Keys.RETURN);
    	    	
    	
    }
    public void clickPsyPal2(){
    	buttonLogin.click();
    }
    public void clickLogin(){
    	buttonLogin.click();
    }
    public void clickProfile(){
    	buttonProfile.sendKeys(Keys.RETURN);
   
    }
    public void setAddress(String strAddr) throws InterruptedException{
    	address.clear();
    	address.sendKeys(strAddr); 
    	Thread.sleep(2000);
    	
    	
    }
    public void updateProfile(){
    	updateProfile.sendKeys(Keys.RETURN);
    	//formClick.click();
   
    }
    
    
    
    	public void linkBooking() throws InterruptedException{
    		linkUID.click();
    		linkIND.click();
    		linkBooking.click();
        	Thread.sleep(2000);
        	linkVoucher.click();
        
    }
    	public void clickLogout(){
            linkLogout.click();
    }
	
	}  



